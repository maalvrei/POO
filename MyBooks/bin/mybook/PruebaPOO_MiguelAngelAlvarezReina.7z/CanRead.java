package mybook;

public interface CanRead {
	void leePagina(boolean silenciosamente);
}
